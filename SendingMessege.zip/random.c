char* random_str() {
   
	int i;
	
	char str[62] ={'q','w','e','r','t','y','u','i','o','p','a','s','d','f','g','h','j','k','l','z','x','c','v','b','n','m',
				'Q','W','E','R','T','Y','U','I','O','P','A','S','D','F','G','H','J','K','L','Z','X','C','V','B','N','M',
				'1','2','3','4','5','6','7','8','9','0'};
	
	char randId[32];
	
	for(i=0; i<32; i++){   
     int number = rand() % 62;
     
     if(number>=0){
     	randId[i] = str[number];
     } else {
     	i--;
     }	
	}

	return randId;
}

char* login(int x){
	char** word = (char**)malloc(sizeof(char*)*2);
	word[0]="pvasiya1";
	word[1]="lyubimayan5";
	
	return word[x];
}

char* password(int x){
	char** word = (char**)malloc(sizeof(char*)*2);
	word[0]="Test1?5?";
	word[1]="Test1?3?";
	
	return word[x];
}
