#ifndef VUSER_WEBSOCKET_BUFFER_HEADER
#define VUSER_WEBSOCKET_BUFFER_HEADER

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive0[] = "{\"id\":1,\"result\":{\"status\":200}}";
long WebSocketReceiveLen0   = sizeof(WebSocketReceive0) - 1;	// (record-time: 32 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive1[] = "{\"id\":2,\"result\":{\"status\":200}}";
long WebSocketReceiveLen1   = sizeof(WebSocketReceive1) - 1;	// (record-time: 32 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive2[] = "{\"id\":3,\"result\":{\"status\":200}}";
long WebSocketReceiveLen2   = sizeof(WebSocketReceive2) - 1;	// (record-time: 32 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive3[] = "{\"id\":4,\"result\":{\"status\":200}}";
long WebSocketReceiveLen3   = sizeof(WebSocketReceive3) - 1;	// (record-time: 32 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive4[] = "{\"id\":5,\"result\":{\"status\":200}}";
long WebSocketReceiveLen4   = sizeof(WebSocketReceive4) - 1;	// (record-time: 32 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive5[] = "{\"id\":6,\"result\":{\"status\":200}}";
long WebSocketReceiveLen5   = sizeof(WebSocketReceive5) - 1;	// (record-time: 32 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive6[] = "{\"id\":7,\"result\":{\"status\":200}}";
long WebSocketReceiveLen6   = sizeof(WebSocketReceive6) - 1;	// (record-time: 32 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive7[] = "{\"id\":8,\"result\":{\"status\":200}}";
long WebSocketReceiveLen7   = sizeof(WebSocketReceive7) - 1;	// (record-time: 32 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive8[] = "{\"method\":\"notice\",\"params\":{\"system\":\"storage\",\"meta\":{\"email\":\""
                        "pvasiya1@mail.ru\"},\"events\":[{\"name\":\"change\",\"data\":{\"revision_prev\""
                        ":41,\"revision_last\":42,\"checksum_prev\":945362114,\"checksum_last\":626776600"
                        "}}]}}";
long WebSocketReceiveLen8   = sizeof(WebSocketReceive8) - 1;	// (record-time: 213 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive9[] = "{\"id\":9,\"result\":{\"status\":200}}";
long WebSocketReceiveLen9   = sizeof(WebSocketReceive9) - 1;	// (record-time: 32 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive10[] = "{\"id\":10,\"result\":{\"status\":200}}";
long WebSocketReceiveLen10   = sizeof(WebSocketReceive10) - 1;	// (record-time: 33 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive11[] = "{\"id\":11,\"result\":{\"status\":200}}";
long WebSocketReceiveLen11   = sizeof(WebSocketReceive11) - 1;	// (record-time: 33 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive12[] = "{\"method\":\"notice\",\"params\":{\"system\":\"storage\",\"meta\":{\"email\":\""
                        "pvasiya1@mail.ru\"},\"events\":[{\"name\":\"change\",\"data\":{\"revision_prev\""
                        ":42,\"revision_last\":43,\"checksum_prev\":626776600,\"checksum_last\":101661037"
                        "0}}]}}";
long WebSocketReceiveLen12   = sizeof(WebSocketReceive12) - 1;	// (record-time: 214 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive13[] = "{\"method\":\"notice\",\"params\":{\"system\":\"storage\",\"meta\":{\"email\":\""
                        "pvasiya1@mail.ru\"},\"events\":[{\"name\":\"change\",\"data\":{\"revision_prev\""
                        ":43,\"revision_last\":44,\"checksum_prev\":1016610370,\"checksum_last\":14446709"
                        "18}}]}}";
long WebSocketReceiveLen13   = sizeof(WebSocketReceive13) - 1;	// (record-time: 215 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive14[] = "{\"id\":12,\"result\":{\"status\":200}}";
long WebSocketReceiveLen14   = sizeof(WebSocketReceive14) - 1;	// (record-time: 33 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive15[] = "{\"id\":13,\"result\":{\"status\":200}}";
long WebSocketReceiveLen15   = sizeof(WebSocketReceive15) - 1;	// (record-time: 33 bytes)

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

char WebSocketReceive16[] = "{\"id\":14,\"result\":{\"status\":200}}";
long WebSocketReceiveLen16   = sizeof(WebSocketReceive16) - 1;	// (record-time: 33 bytes)

#endif
