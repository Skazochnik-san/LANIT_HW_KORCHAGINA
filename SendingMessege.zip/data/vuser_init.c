/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 0
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	lr_start_transaction("start");

	web_add_cookie("searchuid=8335520381534777444; DOMAIN=mail.ru");

	web_add_cookie("b=U0kbAKBYMF4AgaoeCuMPAgqjTj8REcXzECvyZgg966sawd74ETVOPwljwMELr8vzEHEMGwvJfLYZa+80ELtVMQwBAAAIGVMxDBtTMQzL3vgRSVQjCOHHwQtbzsELFQFhCptZZQuVfhkJ2cfBCzHf+An5khUUZL4ohoMc2LZMkGKGFgQA; DOMAIN=mail.ru");

	web_add_cookie("tmr_lvidTS=1621685089525; DOMAIN=mail.ru");

	web_add_cookie("t=obLD1AAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAACAABoJ0AcA; DOMAIN=mail.ru");

	web_add_cookie("tmr_lvid=50f534a3d3a1d864ff5faf28d88f458e; DOMAIN=mail.ru");

	web_add_cookie("s=a=0|octavius=1|fver=0|ww=1536|wh=745|rt=1|dpr=1.25; DOMAIN=mail.ru");

	web_add_cookie("FTID=0; DOMAIN=mail.ru");

	web_add_cookie("tmr_reqNum=811; DOMAIN=mail.ru");

	web_add_cookie("tmr_detect=0%7C1621971974297; DOMAIN=mail.ru");

	web_add_cookie("i=AQCfuaxgAwATAAgHAjwJAXseAl0GBQIBAL0HCAQBghUB; DOMAIN=mail.ru");

	web_add_cookie("p=w5QAAKybEAAA; DOMAIN=mail.ru");

	web_add_cookie("mrcu=C99F60A8F35F09ACD819FB54D25B; DOMAIN=mail.ru");

	web_add_cookie("VID=1su56z1-5FI200000U0yD4o2:::5c7ace9-0-0-5c34c21:CAASEFAyTpT34aXLrfFTOcAMZYgaYEpUvtmahlz0OK8wVF3AbhnO36Txb3zsWqKGqnbMQOPbwgE_uflc6CDH6uiMuc_-ku7-iLdKjjgOikWBI_VczG2qgIB04npfGk2D0qy8C-kZhiCGHBUpNF-ixyNHGb9HUg; DOMAIN=mail.ru");

	web_add_cookie("c=UlStYAMAEHsTAAAkAAAAM83VgS1bAgAI; DOMAIN=mail.ru");

	web_reg_find("Text=Mail.ru: почта, поиск в интернете, новости, игры", 
		LAST);

	web_url("mail.ru", 
		"URL=https://mail.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("tmr_lvidTS=1621685089525; DOMAIN=portal.mail.ru");

	web_add_cookie("t=obLD1AAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAACAABoJ0AcA; DOMAIN=portal.mail.ru");

	web_add_cookie("tmr_lvid=50f534a3d3a1d864ff5faf28d88f458e; DOMAIN=portal.mail.ru");

	web_add_cookie("s=a=0|octavius=1|fver=0|ww=1536|wh=745|rt=1|dpr=1.25; DOMAIN=portal.mail.ru");

	web_add_cookie("FTID=0; DOMAIN=portal.mail.ru");

	web_add_cookie("tmr_reqNum=815; DOMAIN=portal.mail.ru");

	web_add_cookie("p=w5QAAKybEAAA; DOMAIN=portal.mail.ru");

	web_add_cookie("mrcu=C99F60A8F35F09ACD819FB54D25B; DOMAIN=portal.mail.ru");

	web_add_cookie("VID=1su56z1-5FI200000U0yD4o2:::5c7ace9-0-0-5c34c21:CAASEBW_sYI-sQBl6AuFU9FfO4saYEvGpSlY3r_twEHqAqHl4MWC-GLCh7BQ93SeYIZdoTcCYXO78rSDS2NO2icUK75OJaAL20Sti_tIDPsyIg9ksSdaA0ZTc05cx3DIofcOOpRx-J416C2fMtvPdBij179Ycw; DOMAIN=portal.mail.ru");

	web_add_header("Origin", 
		"https://mail.ru");

	web_url("NaviData", 
		"URL=https://portal.mail.ru/NaviData?mac=1&gamescnt=1&Socials=1&rnd=1621972112962", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://mail.ru/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("start",LR_AUTO);

	lr_start_transaction("login");

	web_add_cookie("tmr_lvidTS=1621685089525; DOMAIN=e.mail.ru");

	web_add_cookie("tmr_lvid=50f534a3d3a1d864ff5faf28d88f458e; DOMAIN=e.mail.ru");

	web_add_cookie("FTID=0; DOMAIN=e.mail.ru");

	web_add_cookie("tmr_reqNum=819; DOMAIN=e.mail.ru");

	web_add_cookie("p=w5QAAKybEAAA; DOMAIN=e.mail.ru");

	web_add_cookie("mrcu=C99F60A8F35F09ACD819FB54D25B; DOMAIN=e.mail.ru");

	web_add_cookie("tmr_detect=0%7C1621972051188; DOMAIN=e.mail.ru");

	web_add_cookie("sdcs=JFcj17qC3KPNsO58; DOMAIN=e.mail.ru");

	web_reg_find("Text=Перенаправление", 
		LAST);

	web_submit_data("auth", 
		"Action=https://auth.mail.ru/cgi-bin/auth?from=splash", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://mail.ru/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=Domain", "Value=mail.ru", ENDITEM, 
		"Name=Login", "Value=pvasiya1", ENDITEM, 
		"Name=Password", "Value=Test1?5?", ENDITEM, 
		"Name=new_auth_form", "Value=1", ENDITEM, 
		"Name=FromAccount", "Value=1", ENDITEM, 
		"Name=act_token", "Value=49ada95da0314b809e7d40719f7fa401", ENDITEM, 
		LAST);

	web_add_cookie("sdcs=VIU9r65oLnzEdjqR; DOMAIN=e.mail.ru");

	web_reg_find("Text=Почта Mail.ru", 
		LAST);

	web_url("sdc", 
		"URL=https://auth.mail.ru/sdc?from=https%3A%2F%2Fe.mail.ru%2Fmessages%2Finbox%2F%3Fback%3D1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://e.mail.ru/messages/inbox/?back=1", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("batch", 
		"URL=https://e.mail.ru/api/v1/utils/xray/batch?p=octavius&email=pvasiya1%40mail.ru&r=https%3A%2F%2Fe.mail.ru%2Fmessages%2Finbox%2F%3Fback%3D1&pgid=kp4gc8cx.3l3d&o_v=390", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://e.mail.ru/messages/inbox/?back=1", 
		"Snapshot=t5.inf", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=batch=%5B%7B%22v%22%3A%221%22%2C%22skipdwh%22%3A%22false%22%2C%22t%22%3A%22pk-xray-ready%22%2C%22uid%22%3A%220%22%7D%2C%7B%22v%22%3A%221%22%2C%22skipdwh%22%3A%22false%22%2C%22i%22%3A%22old%3A1%2Cperformance%3A1%2Cload-time%3A1149%2Chttp1%3A1%2Cspd-unknown%3A1%2Cvisible%3A1%22%2C%22t%22%3A%22html-hit%22%2C%22uid%22%3A%221%22%7D%5D", 
		LAST);

	web_custom_request("batch_2", 
		"URL=https://e.mail.ru/api/v1/utils/xray/batch?p=octavius&email=pvasiya1%40mail.ru&r=https%3A%2F%2Fe.mail.ru%2Fmessages%2Finbox%2F%3Fback%3D1&pgid=kp4gc8cx.3l3d&o_v=390", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://e.mail.ru/messages/inbox/?back=1", 
		"Snapshot=t6.inf", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=batch="
		"%5B%7B%22v%22%3A%221%22%2C%22skipdwh%22%3A%22true%22%2C%22t%22%3A%22xray_loadflow_step-0%22%2C%22uid%22%3A%222%22%7D%2C%7B%22v%22%3A%221%22%2C%22skipdwh%22%3A%22true%22%2C%22t%22%3A%22xray_loadflow_step-01%22%2C%22uid%22%3A%223%22%7D%2C%7B%22v%22%3A%221%22%2C%22skipdwh%22%3A%22true%22%2C%22t%22%3A%22pk-device%22%2C%22i%22%3A%22type_unk%3A1%2Cexp_high%3A1%22%2C%22uid%22%3A%224%22%7D%2C%7B%22v%22%3A%2213.5%22%2C%22skipdwh%22%3A%22true%22%2C%22t%22%3A%22pk-nav-net%22%2C%22i%22%3A%22dns%3A0%2Ctcp%3A0%"
		"2Crequest%3A0.39999999999997726%2Cresponse%3A13.100000000000022%22%2C%22uid%22%3A%225%22%7D%2C%7B%22v%22%3A%221%22%2C%22skipdwh%22%3A%22true%22%2C%22t%22%3A%22pk-conn%22%2C%22i%22%3A%22effective_type_unk%3A1%22%2C%22uid%22%3A%226%22%7D%2C%7B%22v%22%3A%221186.2939%22%2C%22skipdwh%22%3A%22true%22%2C%22t%22%3A%22pk-init%22%2C%22i%22%3A%22ver_300000002%3A1%2Cscore_fast%3A1186.2939%22%2C%22uid%22%3A%227%22%7D%5D", 
		LAST);

	web_add_cookie("tmr_reqNum=819; DOMAIN=portal.mail.ru");

	web_add_header("Origin", 
		"https://e.mail.ru");

	web_url("NaviData_2", 
		"URL=https://portal.mail.ru/NaviData?mac=1&Socials=1&ldata=1&Login=pvasiya1%40mail.ru&_=0.7953060074730702", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://e.mail.ru/messages/inbox/?back=1", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("login",LR_AUTO);

	web_custom_request("batch_3", 
		"URL=https://e.mail.ru/api/v1/utils/xray/batch?p=octavius&email=pvasiya1%40mail.ru&r=https%3A%2F%2Fe.mail.ru%2Fmessages%2Finbox%2F%3Fback%3D1&pgid=kp4gc8cx.3l3d&o_v=390", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://e.mail.ru/messages/inbox/?back=1", 
		"Snapshot=t8.inf", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=batch=%5B%7B%22v%22%3A%221%22%2C%22skipdwh%22%3A%22true%22%2C%22t%22%3A%22xray_loadflow_step-8%22%2C%22uid%22%3A%228%22%7D%2C%7B%22v%22%3A%221%22%2C%22skipdwh%22%3A%22true%22%2C%22i%22%3A%22start%3A1%22%2C%22prot%22%3A%22http1%22%2C%22speed%22%3A%22unknown%22%2C%22t%22%3A%22try_js_ajax%22%2C%22uid%22%3A%229%22%7D%2C%7B%22v%22%3A%221%22%2C%22skipdwh%22%3A%22true%22%2C%22t%22%3A%22xray_loadflow_step-28%22%2C%22uid%22%3A%2210%22%7D%5D", 
		LAST);

	return 0;
}
