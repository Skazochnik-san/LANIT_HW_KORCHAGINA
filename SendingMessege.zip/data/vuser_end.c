vuser_end()
{

	web_custom_request("batch_41", 
		"URL=https://e.mail.ru/api/v1/utils/xray/batch?p=octavius&email=pvasiya1%40mail.ru&r=https%3A%2F%2Fe.mail.ru%2Fmessages%2Finbox%2F%3Fback%3D1&pgid=kp4gc8cx.3l3d&o_v=390", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://e.mail.ru/inbox/?back=1", 
		"Snapshot=t110.inf", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=batch="
		"%5B%7B%22v%22%3A%221%22%2C%22skipdwh%22%3A%22false%22%2C%22i%22%3A%22draw%3A1%2Cbr-ie_draw%3A1%2Cs-sidebar_draw%3A1%2Cb-trg-multi_draw%3A1%2Cs-sidebar_b-trg-multi_draw%3A1%2Cvis%3A1%2Cbr-ie_vis%3A1%2Cs-sidebar_vis%3A1%2Cb-trg-multi_vis%3A1%2Cs-sidebar_b-trg-multi_vis%3A1%2Cvis-1%3A1%2Cbr-ie_vis-1%3A1%2Cs-sidebar_vis-1%3A1%2Cb-trg-multi_vis-1%3A1%2Cs-sidebar_b-trg-multi_vis-1%3A1%2Cvis-2%3A1%2Cbr-ie_vis-2%3A1%2Cs-sidebar_vis-2%3A1%2Cb-trg-multi_vis-2%3A1%2Cs-sidebar_b-trg-multi_vis-2%3A1%22%2C%22dw"
		"h%22%3A%22%7B%5C%22slotId%5C%22%3A%5C%22231758%5C%22%2C%5C%22slotName%5C%22%3A%5C%22sidebar%5C%22%2C%5C%22expId%5C%22%3A299%2C%5C%22bannerId%5C%22%3A%5C%2267757478%5C%22%2C%5C%22bannerSource%5C%22%3A%5C%22target%5C%22%2C%5C%22bannerFormat%5C%22%3A%5C%22multi%5C%22%2C%5C%22bannerCount%5C%22%3A1%2C%5C%22searchuid%5C%22%3A%5C%228335520381534777444%5C%22%7D%22%2C%22t%22%3A%22adman%22%2C%22uid%22%3A%22550%22%7D%5D", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"id\":13,\"method\":\"keepalive\",\"params\":{},\"jsonrpc\":\"2.0\"}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive15*/

	lr_think_time(4);

	lr_start_transaction("logout");

	web_websocket_send("ID=0", 
		"Buffer={\"id\":14,\"method\":\"keepalive\",\"params\":{},\"jsonrpc\":\"2.0\"}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive16*/

	web_add_cookie("tmr_reqNum=854; DOMAIN=portal.mail.ru");

	web_add_header("Origin", 
		"https://e.mail.ru");

	web_url("NaviData_5", 
		"URL=https://portal.mail.ru/NaviData?mac=1&Socials=1&ldata=1&Login=pvasiya1%40mail.ru&_=0.7594334735786897", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://e.mail.ru/inbox/?back=1", 
		"Snapshot=t111.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("tmr_reqNum=859; DOMAIN=e.mail.ru");

	web_add_cookie("VID=1su56z1-5FI200000U0yD4o2:::5c7ad75-0-0-5c34c21:CAASECVnj6j_k9wS4QB6jXng5QEaYCXKh7KiRCoczkgdoTtmNT3h-60te72mAYeRSz0pUNS6bU9ux0l2Esf-DkB0xGoreqysRvMkKmTylg3fYeeaK4AbFfsaFWsR9MFwB-TmFrBVsUCIFbO1EOOkilTiYEpN4A; DOMAIN=e.mail.ru");

	web_custom_request("batch_42", 
		"URL=https://e.mail.ru/api/v1/utils/xray/batch?p=octavius&email=pvasiya1%40mail.ru&r=https%3A%2F%2Fe.mail.ru%2Fmessages%2Finbox%2F%3Fback%3D1&pgid=kp4gc8cx.3l3d&o_v=390", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://e.mail.ru/inbox/?back=1", 
		"Snapshot=t112.inf", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=batch=%5B%7B%22v%22%3A%22130455%22%2C%22skipdwh%22%3A%22false%22%2C%22t%22%3A%22p_tab_unload-visible%22%2C%22uid%22%3A%22551%22%7D%5D", 
		LAST);

	web_custom_request("batch_43", 
		"URL=https://e.mail.ru/api/v1/utils/xray/batch?p=octavius&email=pvasiya1%40mail.ru&r=https%3A%2F%2Fe.mail.ru%2Fmessages%2Finbox%2F%3Fback%3D1&pgid=kp4gc8cx.3l3d&o_v=390", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://e.mail.ru/inbox/?back=1", 
		"Snapshot=t113.inf", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=batch=%5B%7B%22v%22%3A%22161958.1939%22%2C%22skipdwh%22%3A%22true%22%2C%22t%22%3A%22pk-unload%22%2C%22i%22%3A%22beforeunload%3A161958.1939%2Ctype_score_5m%3A161958.1939%22%2C%22uid%22%3A%22552%22%7D%5D", 
		LAST);

	web_add_cookie("s=a=0|octavius=1|fver=0|ww=1536|wh=745|dpr=1.25|rt=1; DOMAIN=mail.ru");

	web_add_cookie("tmr_reqNum=859; DOMAIN=mail.ru");

	web_add_cookie("tmr_detect=0%7C1621972122008; DOMAIN=mail.ru");

	web_add_cookie("VID=1su56z1-5FI200000U0yD4o2:::5c7ad75-0-0-5c34c21:CAASELZ3uBhgcMm2FcnoodlEcVsaYL4GYYOw8ScVcfdgmxD8GdOBlFPS53gpezew6fFdIR_NqJaTCi05enkIht6VrOYRn6U_ih0ItnrAWNtWIqXxOv2GRbe2OdVZqFOIsc1QXMD-C980Eaca9Ny9DJt_9pdeJA; DOMAIN=mail.ru");

	web_add_cookie("c=kVStYAMAEHsTAAAkAAAAM83VgS1bAgAI; DOMAIN=mail.ru");

	web_add_cookie("act=49ada95da0314b809e7d40719f7fa401; DOMAIN=mail.ru");

	web_reg_find("Text=Mail.ru: почта, поиск в интернете, новости, игры", 
		LAST);

	web_url("logout", 
		"URL=https://auth.mail.ru/cgi-bin/logout?next=1&lang=ru_RU&page=https%3A%2F%2Fmail.ru%2F%3Ffrom%3Dlogout", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://e.mail.ru/inbox/?back=1", 
		"Snapshot=t114.inf", 
		"Mode=HTML", 
		LAST);

	web_websocket_close("ID=0", 
		"Code=1001", 
		LAST);

	web_add_cookie("tmr_reqNum=859; DOMAIN=portal.mail.ru");

	web_add_header("Origin", 
		"https://mail.ru");

	web_url("NaviData_6", 
		"URL=https://portal.mail.ru/NaviData?mac=1&gamescnt=1&Socials=1&rnd=1621972314461", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://mail.ru/?from=logout", 
		"Snapshot=t115.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("logout",LR_AUTO);

	return 0;
}