vuser_end()
{
	lr_start_transaction("UC05_logout");

	web_add_cookie("tmr_reqNum=854; DOMAIN=portal.mail.ru");

	web_add_cookie("tmr_reqNum=859; DOMAIN=e.mail.ru");

	web_add_cookie("VID=1su56z1-5FI200000U0yD4o2:::5c7ad75-0-0-5c34c21:CAASECVnj6j_k9wS4QB6jXng5QEaYCXKh7KiRCoczkgdoTtmNT3h-60te72mAYeRSz0pUNS6bU9ux0l2Esf-DkB0xGoreqysRvMkKmTylg3fYeeaK4AbFfsaFWsR9MFwB-TmFrBVsUCIFbO1EOOkilTiYEpN4A; DOMAIN=e.mail.ru");

	web_add_cookie("s=a=0|octavius=1|fver=0|ww=1536|wh=745|dpr=1.25|rt=1; DOMAIN=mail.ru");

	web_add_cookie("tmr_reqNum=859; DOMAIN=mail.ru");

	web_add_cookie("tmr_detect=0%7C1621972122008; DOMAIN=mail.ru");

	web_add_cookie("VID=1su56z1-5FI200000U0yD4o2:::5c7ad75-0-0-5c34c21:CAASELZ3uBhgcMm2FcnoodlEcVsaYL4GYYOw8ScVcfdgmxD8GdOBlFPS53gpezew6fFdIR_NqJaTCi05enkIht6VrOYRn6U_ih0ItnrAWNtWIqXxOv2GRbe2OdVZqFOIsc1QXMD-C980Eaca9Ny9DJt_9pdeJA; DOMAIN=mail.ru");

	web_add_cookie("c=kVStYAMAEHsTAAAkAAAAM83VgS1bAgAI; DOMAIN=mail.ru");

	web_add_cookie("act={act_token}; DOMAIN=mail.ru");

	web_url("logout", 
		"URL=https://auth.mail.ru/cgi-bin/logout?next=1&lang=ru_RU&page=https://mail.ru/?from=logout", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://e.mail.ru/inbox/?back=1", 
		"Snapshot=t114.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("tmr_reqNum=859; DOMAIN=portal.mail.ru");

	lr_end_transaction("UC05_logout",LR_AUTO);

	
	return 0;
}