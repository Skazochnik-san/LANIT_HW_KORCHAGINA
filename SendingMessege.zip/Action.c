Action()
{
	int i;
	int xRand;
	xRand = rand() % 2;
	
	lr_start_transaction("UC_transaction");
	
	lr_start_transaction("UC01_start");
	
	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("searchuid=8335520381534777444; DOMAIN=mail.ru");

	web_add_cookie("b=U0kbAKBYMF4AgaoeCuMPAgqjTj8REcXzECvyZgg966sawd74ETVOPwljwMELr8vzEHEMGwvJfLYZa+80ELtVMQwBAAAIGVMxDBtTMQzL3vgRSVQjCOHHwQtbzsELFQFhCptZZQuVfhkJ2cfBCzHf+An5khUUZL4ohoMc2LZMkGKGFgQA; DOMAIN=mail.ru");

	web_add_cookie("tmr_lvidTS=1621685089525; DOMAIN=mail.ru");

	web_add_cookie("t=obLD1AAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAACAABoJ0AcA; DOMAIN=mail.ru");

	web_add_cookie("tmr_lvid=50f534a3d3a1d864ff5faf28d88f458e; DOMAIN=mail.ru");

	web_add_cookie("s=a=0|octavius=1|fver=0|ww=1536|wh=745|rt=1|dpr=1.25; DOMAIN=mail.ru");

	web_add_cookie("FTID=0; DOMAIN=mail.ru");

	web_add_cookie("tmr_reqNum=811; DOMAIN=mail.ru");

	web_add_cookie("tmr_detect=0%7C1621971974297; DOMAIN=mail.ru");

	web_add_cookie("i=AQCfuaxgAwATAAgHAjwJAXseAl0GBQIBAL0HCAQBghUB; DOMAIN=mail.ru");

	web_add_cookie("p=w5QAAKybEAAA; DOMAIN=mail.ru");

	web_add_cookie("mrcu=C99F60A8F35F09ACD819FB54D25B; DOMAIN=mail.ru");

	web_add_cookie("VID=1su56z1-5FI200000U0yD4o2:::5c7ace9-0-0-5c34c21:CAASEFAyTpT34aXLrfFTOcAMZYgaYEpUvtmahlz0OK8wVF3AbhnO36Txb3zsWqKGqnbMQOPbwgE_uflc6CDH6uiMuc_-ku7-iLdKjjgOikWBI_VczG2qgIB04npfGk2D0qy8C-kZhiCGHBUpNF-ixyNHGb9HUg; DOMAIN=mail.ru");

	web_add_cookie("c=UlStYAMAEHsTAAAkAAAAM83VgS1bAgAI; DOMAIN=mail.ru");

	web_reg_save_param_regexp(
		"ParamName=act_token",
		"RegExp=act=(.*?);",
		SEARCH_FILTERS,
		"Scope=Cookies",
		"IgnoreRedirections=No",
		"RequestUrl=*/mail.ru/*",
		LAST);

	web_url("mail.ru", 
		"URL=https://mail.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("tmr_lvidTS=1621685089525; DOMAIN=portal.mail.ru");

	web_add_cookie("t=obLD1AAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAACAABoJ0AcA; DOMAIN=portal.mail.ru");

	web_add_cookie("tmr_lvid=50f534a3d3a1d864ff5faf28d88f458e; DOMAIN=portal.mail.ru");

	web_add_cookie("s=a=0|octavius=1|fver=0|ww=1536|wh=745|rt=1|dpr=1.25; DOMAIN=portal.mail.ru");

	web_add_cookie("FTID=0; DOMAIN=portal.mail.ru");

	web_add_cookie("tmr_reqNum=815; DOMAIN=portal.mail.ru");

	web_add_cookie("p=w5QAAKybEAAA; DOMAIN=portal.mail.ru");

	web_add_cookie("mrcu=C99F60A8F35F09ACD819FB54D25B; DOMAIN=portal.mail.ru");

	web_add_cookie("VID=1su56z1-5FI200000U0yD4o2:::5c7ace9-0-0-5c34c21:CAASEBW_sYI-sQBl6AuFU9FfO4saYEvGpSlY3r_twEHqAqHl4MWC-GLCh7BQ93SeYIZdoTcCYXO78rSDS2NO2icUK75OJaAL20Sti_tIDPsyIg9ksSdaA0ZTc05cx3DIofcOOpRx-J416C2fMtvPdBij179Ycw; DOMAIN=portal.mail.ru");

	lr_end_transaction("UC01_start",LR_AUTO);

	lr_start_transaction("UC02_login");

	web_add_cookie("tmr_lvidTS=1621685089525; DOMAIN=e.mail.ru");

	web_add_cookie("tmr_lvid=50f534a3d3a1d864ff5faf28d88f458e; DOMAIN=e.mail.ru");

	web_add_cookie("FTID=0; DOMAIN=e.mail.ru");

	web_add_cookie("tmr_reqNum=819; DOMAIN=e.mail.ru");

	web_add_cookie("p=w5QAAKybEAAA; DOMAIN=e.mail.ru");

	web_add_cookie("mrcu=C99F60A8F35F09ACD819FB54D25B; DOMAIN=e.mail.ru");

	web_add_cookie("tmr_detect=0%7C1621972051188; DOMAIN=e.mail.ru");

	web_add_cookie("sdcs=JFcj17qC3KPNsO58; DOMAIN=e.mail.ru");

	lr_save_string(login(xRand), "LOGIN");
	lr_save_string(password(xRand), "PASSWORD");
	
	web_submit_data("auth",
		"Action=https://auth.mail.ru/cgi-bin/auth?from=splash",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://mail.ru/",
		"Snapshot=t3.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=Domain", "Value=mail.ru", ENDITEM,
		"Name=Login", "Value={LOGIN}", ENDITEM,
		"Name=Password", "Value={PASSWORD}", ENDITEM,
		"Name=new_auth_form", "Value=1", ENDITEM,
		"Name=FromAccount", "Value=1", ENDITEM,
		"Name=act_token", "Value={act_token}", ENDITEM,
		LAST);

	lr_end_transaction("UC02_login",LR_AUTO);
	
	for(i=1; i<=3; i++){
		
	web_add_cookie("sdcs=VIU9r65oLnzEdjqR; DOMAIN=e.mail.ru");

	web_reg_save_param_regexp(
		"ParamName=token",
		"RegExp=\"token\":\"(.*?)\",",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/inbox/*",
		LAST);
	 
	web_url("sdc", 
		"URL=https://auth.mail.ru/sdc?from=https://e.mail.ru/messages/inbox/?back=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://e.mail.ru/messages/inbox/?back=1", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("tmr_reqNum=819; DOMAIN=portal.mail.ru"); 
	
	lr_start_transaction("UC03_creatLetter");

	web_url("aliases",
		"URL=https://e.mail.ru/api/v1/aliases?email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1621972176367",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/messages/inbox/?back=1",
		"Snapshot=t11.inf",
		"Mode=HTML",
		LAST);

	web_add_cookie("tmr_lvidTS=1621685089525; DOMAIN=ad.mail.ru");

	web_add_cookie("tmr_lvid=50f534a3d3a1d864ff5faf28d88f458e; DOMAIN=ad.mail.ru");

	web_add_cookie("FTID=0; DOMAIN=ad.mail.ru");

	web_add_cookie("tmr_reqNum=819; DOMAIN=ad.mail.ru");

	web_add_cookie("p=w5QAAKybEAAA; DOMAIN=ad.mail.ru");

	web_add_cookie("mrcu=C99F60A8F35F09ACD819FB54D25B; DOMAIN=ad.mail.ru");

	web_add_auto_header("Origin", 
		"https://e.mail.ru");

	web_revert_auto_header("Origin");

	web_add_cookie("VID=1su56z1-5FI200000U0yD4o2:::5c7ace9-0-0-5c34c21:CAASEM4jG3DSK9k5ZylfPKNccu4aYLA72Z79lH1z8vjcqCZJo6D2LvHOgZOtmqYAb84UllpZ0UtiJlyaWq1YBxpnFKGHYUixI0aDlN-KSNVE6ujNIMCgYRHVC7Gx0lfHhJjNBaAP57TzMUCqqiTdfWux_cPDeQ; DOMAIN=e.mail.ru");

	web_submit_data("update",
		"Action=https://e.mail.ru/api/v1/helpers/update",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/?back=1",
		"Snapshot=t19.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=index", "Value=305", ENDITEM,
		"Name=update", "Value={\"count\":{\"show\":true}}", ENDITEM,
		"Name=email", "Value={LOGIN}@mail.ru", ENDITEM,
		"Name=htmlencoded", "Value=false", ENDITEM,
		"Name=token", "Value={token}", ENDITEM,
		LAST);

	web_add_cookie("tmr_reqNum=831; DOMAIN=ad.mail.ru");

	web_add_cookie("VID=1su56z1-5FI200000U0yD4o2:::5c7ad75-0-0-5c34c21:CAASED2bU5iHG6pJf1KFGKH_qYUaYBTR2d7apjG0JlD5eCCVwejj4ZPC2cr7bn-IrjSfmJT8DKHi-9eC8vc6_pp558hLO--bw91KSyAcsf0Y2W1vHlahT_vTORfqBiNUv1znRfI7dTS0rRJxSQiWbxvq9Zjfhg; DOMAIN=ad.mail.ru");

	web_add_cookie("tmr_reqNum=831; DOMAIN=e.mail.ru");

	web_add_cookie("VID=1su56z1-5FI200000U0yD4o2:::5c7ad75-0-0-5c34c21:CAASED2bU5iHG6pJf1KFGKH_qYUaYBTR2d7apjG0JlD5eCCVwejj4ZPC2cr7bn-IrjSfmJT8DKHi-9eC8vc6_pp558hLO--bw91KSyAcsf0Y2W1vHlahT_vTORfqBiNUv1znRfI7dTS0rRJxSQiWbxvq9Zjfhg; DOMAIN=e.mail.ru");

	web_url("requests",
		"URL=https://e.mail.ru/api/v1/messages/search/requests?query=&limit=5&email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1621972184535",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/?back=1",
		"Snapshot=t25.inf",
		"Mode=HTML",
		LAST);

	web_add_cookie("tmr_reqNum=837; DOMAIN=e.mail.ru");

	web_add_cookie("VID=1su56z1-5FI200000U0yD4o2:::5c7ad75-0-0-5c34c21:CAASEMLl-1HIA0XROedJJhdX8TsaYMCX6r9PFiAq7LdwGiYZS4tKPuyKHGHELVNorDUQNFPpQRWDrMS5eycqKhOEiuhYcEmIEsOeC8yQnpEyZ3aCcAw1uUVeHc2bWAMwMdyIL1I6lWL23z7Lr4vH4E4EkMJGRg; DOMAIN=e.mail.ru");

	web_add_cookie("VID=1su56z1-5FI200000U0yD4o2:::5c7ad75-0-0-5c34c21:CAASEFusmjHwi4Tno_z0GAxregIaYD-WCIUP7OGDqwFhFNThXggeLLPjv843ErKJBf6NMSEYg7YalnDbX_iKXK2e3LuH7kvQ4ejQnAlyjteXf5-VyXL2TE9LlWyLN_40NJa1uB9LNBI3oMlz7sVXOmkzcqylMA; DOMAIN=e.mail.ru");

	web_url("security",
		"URL=https://e.mail.ru/api/v1/golang/user/security?email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1621972186350",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/?back=1",
		"Snapshot=t28.inf",
		"Mode=HTML",
		LAST);

	web_url("short",
		"URL=https://e.mail.ru/api/v1/user/short?email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1621972186355",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/?back=1",
		"Snapshot=t29.inf",
		"Mode=HTML",
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive1*/

	web_add_cookie("tmr_detect=0%7C1621972187539; DOMAIN=e.mail.ru");

	web_reg_save_param_json(
		"ParamName=token_1",
		"QueryString=$.body.token",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_submit_data("short_2",
		"Action=https://e.mail.ru/api/v1/user/short",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/?back=1",
		"Snapshot=t31.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=email", "Value={LOGIN}@mail.ru", ENDITEM,
		"Name=htmlencoded", "Value=false", ENDITEM,
		"Name=token", "Value={token}", ENDITEM,
		LAST);

	lr_end_transaction("UC03_creatLetter",LR_AUTO);

	web_add_cookie("tmr_reqNum=842; DOMAIN=e.mail.ru");

	web_add_cookie("tmr_reqNum=842; DOMAIN=portal.mail.ru");
		
    lr_save_string(random_str(), "TEG_MESSAG");
	lr_save_string(random_str(), "MESSAG_TEXT");
	lr_save_string(random_str(), "ID_MESSAG");
	
	lr_start_transaction("UC04_sendLetter");
	
	web_submit_data("send",
		"Action=https://e.mail.ru/api/v1/messages/send",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/?back=1",
		"Snapshot=t96.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=from", "Value={NAME_LOGIN} <{LOGIN}@mail.ru>", ENDITEM,
		"Name=id", "Value={ID_MESSAG}", ENDITEM,
		"Name=source", "Value={\"draft\":\"\",\"reply\":\"\",\"forward\":\"\",\"schedule\":\"\"}", ENDITEM,
		"Name=headers", "Value={}", ENDITEM,
		"Name=template", "Value=0", ENDITEM,
		"Name=sign", "Value=0", ENDITEM,
		"Name=remind", "Value=0", ENDITEM,
		"Name=receipt", "Value=false", ENDITEM,
		"Name=subject", "Value={TEG_MESSAG}", ENDITEM,
		"Name=priority", "Value=3", ENDITEM,
		"Name=send_date", "Value=", ENDITEM,
		"Name=body", "Value={\"html\":\"<div>{MESSAG_TEXT}</div><div>&nbsp;</div><div data-signature-widget=\\\"container\\\"><div data-signature-widget=\\\"content\\\"><div>--<br>{NAME_LOGIN}</div></div></div>\",\"text\":\"{MESSAG_TEXT}\\r\\n"
		"\\r\\n"
		"\\r\\n"
		"\\r\\n"
		"\\r\\n"
		"\\r\\n"
		"\\r\\n"
		"\\r\\n"
		"\\r\\n"
		"Подпись\\r\\n"
		"\\r\\n"
		"\\r\\n"
		"\\r\\n"
		"--\\r\\n"
		"{NAME_LOGIN}\"}", ENDITEM,
		"Name=correspondents", "Value={\"to\":\"{CORRESPONDENTS}\",\"cc\":\"\",\"bcc\":\"\"}", ENDITEM,
		"Name=folder_id", "Value=", ENDITEM,
		"Name=sending", "Value=true", ENDITEM,
		"Name=compose_stat", "Value={\"user_track\":\"m|3053|325|1|1;m|11981|361|2|1;m|185|126|1|0;m|178|54|1|0;m|181|6|1|0;m|199|8|1|1;m|210|8|1|0;c|311|0|488|253.59999084472656;m|570|29|1|1;m|191|33|1|1;c|366|0|428|254.39999389648437;k|517|1;k|522|6;k|5372|6;m|6351|77|1|1;m|206|37|1|0;m|186|1|1|0;m|396|66|1|1;m|194|3|1|0;m|260|126|1|1;m|179|56|1|0;m|174|56|1|1;m|194|13|1|0;c|725|0|478.3999938964844|88.79999542236328;k|1371|1;k|53|6;k|10410|6;m|6999|248|2|1;m|172|33|1|0;c|706|0|754.3999633789062|132.8000030517578;k|2514|1;k|7|6;k|574|6;k|1319|19;k|515|6;k|431|6;k|36|6;k|12|6;k|39|6;k|9|6;k|39|6;k|10|6;k|35|6;k|13|6;m|5440|147|1|1;m|171|23|1|0;c|750|0|685.5999755859375|285.6000061035156;m|490|329|2|1;m|23651|550|3|1;m|175|264|2|0;m|171|17|1|0;m|199|41|1|1;m|211|20|1|0;m|182|27|1|1;m|200|24|1|0;m|212|2|1|0;c|840|0|424|672.7999877929687\",\"build\":\"release-fmail-13039.+053356-09-15T07_54_57\",\"serverTime\":1621607963024}", ENDITEM,
		"Name=delay_for_cancellation", "Value=false", ENDITEM,
		"Name=attaches", "Value={\"list\":[]}", ENDITEM,
		"Name=email", "Value={LOGIN}@mail.ru", ENDITEM,
		"Name=htmlencoded", "Value=false", ENDITEM,
		"Name=token", "Value={token_1}", ENDITEM,
		LAST);

	web_add_cookie("tmr_reqNum=842; DOMAIN=ad.mail.ru");
	web_add_cookie("tmr_reqNum=848; DOMAIN=e.mail.ru");
	web_add_cookie("tmr_reqNum=848; DOMAIN=ad.mail.ru");
	
	lr_end_transaction("UC04_sendLetter",LR_AUTO);
	sleep(2500);
}
	
	web_add_cookie("tmr_reqNum=854; DOMAIN=e.mail.ru");
	
	lr_end_transaction("UC_transaction", LR_AUTO);

	return 0;
}
