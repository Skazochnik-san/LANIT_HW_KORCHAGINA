int randomNumber(int size){
	return (1 + rand() % size);
}