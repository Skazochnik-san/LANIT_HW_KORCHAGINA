Action()
{
	int xMess;
	int xRand;
	char stringID[20];
	char stringIDMess[20];
	
	lr_start_transaction("UC_transaction");
	
	lr_start_transaction("UC01_start");
	
	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("searchuid=8335520381534777444; DOMAIN=mail.ru");

	web_add_cookie("b=VkkIAKBoCw0AoSibClFWvQupxlgKKZ7FCLkRZAzhSaIIwRZkDMNZpAoHAAAAIUw/TnOE8//niVBq9YwA; DOMAIN=mail.ru");

	web_add_cookie("tmr_lvidTS=1621685089525; DOMAIN=mail.ru");

	web_add_cookie("t=obLD1AAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAACAABoJ0AcA; DOMAIN=mail.ru");

	web_add_cookie("tmr_lvid=50f534a3d3a1d864ff5faf28d88f458e; DOMAIN=mail.ru");

	web_add_cookie("s=a=0|octavius=1|fver=0|ww=1536|wh=745|dpr=1.25|rt=1; DOMAIN=mail.ru");

	web_add_cookie("FTID=0; DOMAIN=mail.ru");

	web_add_cookie("tmr_reqNum=875; DOMAIN=mail.ru");

	web_add_cookie("i=AQAkrLBgAwATAAgHAjwJAXseAl0GBQIBAL0HCAQBghUB; DOMAIN=mail.ru");

	web_add_cookie("p=w5QAAKybEAAA; DOMAIN=mail.ru");

	web_add_cookie("mrcu=C99F60A8F35F09ACD819FB54D25B; DOMAIN=mail.ru");

	web_add_cookie("VID=1su56z1-5FI200000U0yD4o2:::5c7ad75-0-0-5c34c21:CAASECRw_n-P7w4DK-AoMEGlyHYaYKYlG3mwE5CQyZwleppRZ_Bfgc4k3fNMQB4DOrBUAbBS-Ykllq8VsBAzp1Q_U1PoOlWA8VGRfoxesoAOVc-2IYsd2VAa5B9n1RoQXLBpDZKnGh3wpjQ4JUcu1FMdEOFIuQ; DOMAIN=mail.ru");

	web_add_cookie("c=FtCwYAEAAHsTAAAUAAAACQAQ; DOMAIN=mail.ru");

	web_reg_save_param_regexp(
		"ParamName=act_token",
		"RegExp=act=(.*?);",
		"NotFound=warning",
		SEARCH_FILTERS,
		"Scope=COOKIES",
		"RequestUrl=*/mail.ru/*",
		LAST);

	web_url("mail.ru", 
		"URL=https://mail.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("tmr_lvidTS=1621685089525; DOMAIN=portal.mail.ru");

	web_add_cookie("t=obLD1AAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAACAABoJ0AcA; DOMAIN=portal.mail.ru");

	web_add_cookie("tmr_lvid=50f534a3d3a1d864ff5faf28d88f458e; DOMAIN=portal.mail.ru");

	web_add_cookie("s=a=0|octavius=1|fver=0|ww=1536|wh=745|dpr=1.25|rt=1; DOMAIN=portal.mail.ru");

	web_add_cookie("FTID=0; DOMAIN=portal.mail.ru");

	web_add_cookie("tmr_reqNum=879; DOMAIN=portal.mail.ru");

	web_add_cookie("p=w5QAAKybEAAA; DOMAIN=portal.mail.ru");

	web_add_cookie("mrcu=C99F60A8F35F09ACD819FB54D25B; DOMAIN=portal.mail.ru");

	web_add_cookie("VID=1su56z1-5FI200000U0yD4o2:::5c7ad75-0-0-5c34c21:CAASEF1E2LIQUAGCx2HZ4TlyJz0aYCrMfqy6YRjRsurW68CvPrwUmTLwy66D6auVA36hGNl9NR0ZUdEqY3zLZ3TRpfaWH-Bij-MAwIt9q6d7oRS_i_Gb7HDK1WUuA9pWiQgRI9kkhbCx_vge3MMs3uwjwZgx1Q; DOMAIN=portal.mail.ru");

	web_add_auto_header("Origin", 
		"https://mail.ru");

	lr_end_transaction("UC01_start",LR_AUTO);

	lr_start_transaction("UC02_login");

	web_add_cookie("tmr_reqNum=885; DOMAIN=portal.mail.ru");

	web_revert_auto_header("Origin");

	web_add_cookie("tmr_lvidTS=1621685089525; DOMAIN=e.mail.ru");

	web_add_cookie("tmr_lvid=50f534a3d3a1d864ff5faf28d88f458e; DOMAIN=e.mail.ru");

	web_add_cookie("FTID=0; DOMAIN=e.mail.ru");

	web_add_cookie("tmr_reqNum=885; DOMAIN=e.mail.ru");

	web_add_cookie("p=w5QAAKybEAAA; DOMAIN=e.mail.ru");

	web_add_cookie("mrcu=C99F60A8F35F09ACD819FB54D25B; DOMAIN=e.mail.ru");

	web_add_cookie("sdcs=VIU9r65oLnzEdjqR; DOMAIN=e.mail.ru");

	web_submit_data("auth",
		"Action=https://auth.mail.ru/cgi-bin/auth?from=splash",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://mail.ru/",
		"Snapshot=t4.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=Domain", "Value=mail.ru", ENDITEM,
		"Name=Login", "Value={LOGIN}", ENDITEM,
		"Name=Password", "Value={PASSWORD}", ENDITEM,
		"Name=new_auth_form", "Value=1", ENDITEM,
		"Name=FromAccount", "Value=1", ENDITEM,
		"Name=act_token", "Value={act_token}", ENDITEM,
		LAST);

	web_add_cookie("sdcs=ncIdMHKbWrDFqSia; DOMAIN=e.mail.ru");
	
	lr_end_transaction("UC02_login", LR_AUTO);
	
	
	web_reg_save_param_regexp(
		"ParamName=token",
		"RegExp=\"token\":\"(.*?)\",",
		"NotFound=warning",
		SEARCH_FILTERS,
		"Scope=BODY",
		"RequestUrl=*/inbox/*",
		LAST);

	web_url("sdc", 
		"URL=https://auth.mail.ru/sdc?from=https://e.mail.ru/messages/inbox/?back=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://e.mail.ru/messages/inbox/?back=1", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_convert_param("token_URL2",
		"SourceString={token}",
		"SourceEncoding=HTML",
		"TargetEncoding=URL",
		LAST);

	web_url("aliases",
		"URL=https://e.mail.ru/api/v1/aliases?email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1622200890463",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/messages/inbox/?back=1",
		"Snapshot=t10.inf",
		"Mode=HTML",
		LAST);


	web_reg_save_param_regexp(
		"ParamName=messages_unread",
		"RegExp=\"Входящие\",\"messages_unread\":(.*?),",
		"Ordinal=all",
		"NotFound=warning",
		SEARCH_FILTERS,
		"Scope=BODY",
		"RequestUrl=*/smart*",
		"IgnoreRedirections=Yes",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=id",
		"RegExp=\"id\":\"(1:.*?:0)\",",
		"Ordinal=all",
		"NotFound=warning",
		SEARCH_FILTERS,
		"Scope=BODY",
		"RequestUrl=*/smart*",
		"IgnoreRedirections=Yes",
		LAST);	
		
	web_reg_save_param_regexp(
		"ParamName=id_1",
		"RegExp=\"last\":\"(.*?)\",\"expand\"",
		"Ordinal=all",
		"NotFound=warning",
		SEARCH_FILTERS,
		"Scope=BODY",
		"RequestUrl=*/smart*",
		"IgnoreRedirections=Yes",
		LAST);	

	web_url("smart",
		"URL=https://e.mail.ru/api/v1/threads/status/smart?folder=0&limit=50&filters=%7B%7D&last_modified=1&force_custom_thread=true&supported_custom_metathreads=[%22tomyself%22]&pinned_limit=0&offset=0&email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1622200890478",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/messages/inbox/?back=1",
		"Snapshot=t11.inf",
		"Mode=HTML",
		LAST);	
			
	xMess = atoi(lr_eval_string("{messages_unread_1}"));
	
	if(xMess == 0){

		lr_message("Сообщений нет!!");

		lr_abort( );
		
		return 0;
	}
	
	if(xMess<=50){
		xRand = randomNumber(xMess);
	} else {
		xMess = 49;
		xRand = randomNumber(xMess);
	}
	
	sprintf(stringID, "{id_%d}", xRand);
	
	sprintf(stringIDMess, "{id_1_%d}", xRand);
	
	lr_save_string(lr_eval_string(stringID), "id");
	lr_save_string(lr_eval_string(stringIDMess), "id_1");
	
	
	web_convert_param("id_URL2",
		"SourceString={id}",
		"SourceEncoding=HTML",
		"TargetEncoding=URL",
		LAST);

	web_add_cookie("tmr_lvidTS=1621685089525; DOMAIN=ad.mail.ru");

	web_add_cookie("tmr_lvid=50f534a3d3a1d864ff5faf28d88f458e; DOMAIN=ad.mail.ru");

	web_add_cookie("FTID=0; DOMAIN=ad.mail.ru");

	web_add_cookie("tmr_reqNum=885; DOMAIN=ad.mail.ru");

	web_add_cookie("p=w5QAAKybEAAA; DOMAIN=ad.mail.ru");

	web_add_cookie("mrcu=C99F60A8F35F09ACD819FB54D25B; DOMAIN=ad.mail.ru");

	web_add_auto_header("Origin", 
		"https://e.mail.ru");

	web_revert_auto_header("Origin");

	web_submit_data("update",
		"Action=https://e.mail.ru/api/v1/helpers/update",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/?back=1",
		"Snapshot=t18.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=index", "Value=305", ENDITEM,
		"Name=update", "Value={\"count\":{\"show\":true}}", ENDITEM,
		"Name=email", "Value={LOGIN}@mail.ru", ENDITEM,
		"Name=htmlencoded", "Value=false", ENDITEM,
		"Name=token", "Value={token}", ENDITEM,
		LAST);

	web_add_cookie("tmr_reqNum=897; DOMAIN=ad.mail.ru");

	web_add_cookie("tmr_reqNum=897; DOMAIN=e.mail.ru");

	web_url("requests",
		"URL=https://e.mail.ru/api/v1/messages/search/requests?query=&limit=5&email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1622200899051",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/?back=1",
		"Snapshot=t27.inf",
		"Mode=HTML",
		LAST);

	web_add_cookie("b=VkkKAKBoCw0AoSibClFWvQupxlgKKZ7FCLkRZAzhSaIIwRZkDMNZpAodNU4LY8zrCwcAAAAhTD9Oc4Tz/+eJUGr1jAAA; DOMAIN=e.mail.ru");

	web_add_cookie("tmr_reqNum=903; DOMAIN=e.mail.ru");

	web_url("security",
		"URL=https://e.mail.ru/api/v1/golang/user/security?email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1622200901790",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/?back=1",
		"Snapshot=t29.inf",
		"Mode=HTML",
		LAST);

	web_url("short",
		"URL=https://e.mail.ru/api/v1/user/short?email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1622200901794",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/?back=1",
		"Snapshot=t30.inf",
		"Mode=HTML",
		LAST);

	web_url("unread",
		"URL=https://e.mail.ru/api/v1/golang/messages/services/cleanmaster/unread?email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1622200901980",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/?back=1",
		"Snapshot=t32.inf",
		"Mode=HTML",
		LAST);

	web_add_cookie("tmr_detect=0%7C1622200902671; DOMAIN=e.mail.ru");

	web_add_cookie("tmr_reqNum=908; DOMAIN=e.mail.ru");

	web_add_cookie("tmr_reqNum=908; DOMAIN=ad.mail.ru");

	web_add_auto_header("Origin", 
		"https://e.mail.ru");

	web_add_cookie("tmr_reqNum=908; DOMAIN=portal.mail.ru");

	web_revert_auto_header("Origin");

	web_add_cookie("tmr_reqNum=914; DOMAIN=e.mail.ru");

	lr_start_transaction("UC03_openRndLetter");

	web_url("smart_3",
		"URL=https://e.mail.ru/api/v1/threads/status/smart?folder=0&limit=50&filters=%7B%7D&last_modified=1622200890&force_custom_thread=true&supported_custom_metathreads=[%22tomyself%22]&offset=0&email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1622200929275",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/?back=1",
		"Snapshot=t42.inf",
		"Mode=HTML",
		LAST);

	web_url("srv-st.json", 
		"URL=https://e.mail.ru/srv-st.json?_=0.7241460109802967", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://e.mail.ru/inbox/?back=1", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		LAST);

	web_url("hash",
		"URL=https://e.mail.ru/api/v1/utils/sota/hash?token={token_URL2}&email={LOGIN}%40mail.ru&_=0.06565216205244595",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/?back=1",
		"Snapshot=t45.inf",
		"Mode=HTML",
		LAST);

	web_url("smart_4",
		"URL=https://e.mail.ru/api/v1/messages/replies/smart?id={id_1}&email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1622200931349",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/{id}/?back=1",
		"Snapshot=t46.inf",
		"Mode=HTML",
		LAST);

	web_add_cookie("tmr_reqNum=914; DOMAIN=ad.mail.ru");

	web_submit_data("marks",
		"Action=https://e.mail.ru/api/v1/messages/marks",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/{id}/?back=1",
		"Snapshot=t49.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=marks", "Value=[{\"name\":\"unread\",\"unset\":[\"{id_1}\"],\"folder\":0}]", ENDITEM,
		"Name=email", "Value={LOGIN}@mail.ru", ENDITEM,
		"Name=htmlencoded", "Value=false", ENDITEM,
		"Name=token", "Value={token}", ENDITEM,
		LAST);

	web_url("smart_5",
		"URL=https://e.mail.ru/api/v1/threads/status/smart?folder=0&limit=50&filters=%7B%7D&last_modified=1622200890&force_custom_thread=true&supported_custom_metathreads=[%22tomyself%22]&offset=0&email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1622200931999",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/{id}/?back=1",
		"Snapshot=t50.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("UC03_openRndLetter",LR_AUTO);

	lr_start_transaction("UC04_folderRead");

	web_url("smart_6",
		"URL=https://e.mail.ru/api/v1/threads/status/smart?folder=0&limit=50&filters=%7B%7D&last_modified=1622200932&force_custom_thread=true&supported_custom_metathreads=[%22tomyself%22]&offset=0&email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1622200964336",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/{id}/?back=1",
		"Snapshot=t55.inf",
		"Mode=HTML",
		LAST);

	web_add_cookie("tmr_reqNum=920; DOMAIN=e.mail.ru");

	web_url("srv-st.json_2",
		"URL=https://e.mail.ru/srv-st.json?_=0.8656844397856618",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/{id}/?back=1",
		"Snapshot=t58.inf",
		"Mode=HTML",
		LAST);

	web_url("hash_2",
		"URL=https://e.mail.ru/api/v1/utils/sota/hash?token={token_URL2}&email={LOGIN}%40mail.ru&_=0.7314409393509602",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/{id}/?back=1",
		"Snapshot=t59.inf",
		"Mode=HTML",
		LAST);

	web_add_cookie("tmr_reqNum=920; DOMAIN=ad.mail.ru");

	web_submit_data("move",
		"Action=https://e.mail.ru/api/v1/threads/move",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/1:121dc92c89b109ba:0/?back=1",
		"Snapshot=t62.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=ids", "Value=[\"{id}\"]", ENDITEM,
		"Name=msg_ids", "Value=[{\"id\":\"{id}\",\"folder\":\"0\"}]", ENDITEM,
		"Name=folder", "Value=1", ENDITEM,
		"Name=message_id_last", "Value={\"{id}\":\"{id_1}\"}", ENDITEM,
		"Name=email", "Value={LOGIN}@mail.ru", ENDITEM,
		"Name=htmlencoded", "Value=false", ENDITEM,
		"Name=token", "Value={token}", ENDITEM,
		LAST);
	
	web_url("smart_7",
		"URL=https://e.mail.ru/api/v1/messages/replies/smart?id=16219534431185229338&email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1622200966325",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/1:121dc92c89b109ba:0/?back=1",
		"Snapshot=t63.inf",
		"Mode=HTML",
		LAST);

	web_url("smart_8",
		"URL=https://e.mail.ru/api/v1/threads/status/smart?folder=0&limit=50&filters=%7B%7D&last_modified=1622200932&force_custom_thread=true&supported_custom_metathreads=[%22tomyself%22]&offset=0&email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1622200966658",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/1:121dc92c89b109ba:0/?back=1",
		"Snapshot=t65.inf",
		"Mode=HTML",
		LAST);

	web_url("smart_9",
		"URL=https://e.mail.ru/api/v1/threads/status/smart?folder=0&limit=50&filters=%7B%7D&last_modified=1622200966&force_custom_thread=true&supported_custom_metathreads=[%22tomyself%22]&offset=0&email={LOGIN}%40mail.ru&htmlencoded=false&token={token}&_=1622200967355",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/1:121dc92c89b109ba:0/?back=1",
		"Snapshot=t68.inf",
		"Mode=HTML",
		LAST);	

	lr_end_transaction("UC04_folderRead",LR_AUTO);
	

	web_add_cookie("tmr_reqNum=920; DOMAIN=portal.mail.ru");

	web_add_auto_header("Origin", 
		"https://e.mail.ru");

	lr_end_transaction("UC_transaction", LR_AUTO);

	return 0;
}
