vuser_end()
{
	lr_start_transaction("UC05_logout");

	web_revert_auto_header("Origin");

	web_add_cookie("tmr_reqNum=925; DOMAIN=e.mail.ru");

	web_add_cookie("b=VkkKAKBoCw0AoSibClFWvQupxlgKKZ7FCLkRZAzhSaIIwRZkDMNZpAodNU4L8Q6WCQcAAAAhTD9Oc4Tz/+eJUGr1jAAA; DOMAIN=mail.ru");

	web_add_cookie("t=obLD1AAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAAAAAAAAAACAAAYH0gcA; DOMAIN=mail.ru");

	web_add_cookie("s=a=0|octavius=1|fver=0|ww=1536|wh=745|rt=1|dpr=1.25; DOMAIN=mail.ru");

	web_add_cookie("tmr_reqNum=925; DOMAIN=mail.ru");

	web_add_cookie("i=AQAkrLBgAwATAAgHAjwJAXseAV0GBQIBAL0HCAQBghUB; DOMAIN=mail.ru");

	web_add_cookie("VID=1su56z1-5FI200000U0yD4o2:::5cb2adf-0-0-5c34c21:CAASENuMjQyIVX3MXr9LDH0jmL8aYENRqhcC8zDvEz-FzGP_Z4YPaCTgYpIGhO61cV-GI6jecJqbk-tcQvxZ6kTc63b7nVCpeAz5QhT3SDqp5PwlJga9EkYW6Re4gYDrVlArERntnbJuJ6UseIC_GIodJHmIqg; DOMAIN=mail.ru");

	web_add_cookie("c=RdKwYAIAEHsTAAAUAAAAM811AgAI; DOMAIN=mail.ru");

	web_add_cookie("act={act_token}; DOMAIN=mail.ru");

	web_add_cookie("tmr_detect=1%7C1622200812290; DOMAIN=mail.ru");

	web_url("logout", 
		"URL=https://auth.mail.ru/cgi-bin/logout?next=1&lang=ru_RU&page=https%3A%2F%2Fmail.ru%2F%3Ffrom%3Dlogout", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://e.mail.ru/inbox/1:121dc92c89b109ba:0/?back=1", 
		"Snapshot=t75.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("tmr_reqNum=925; DOMAIN=portal.mail.ru");

	lr_end_transaction("UC05_logout",LR_AUTO);
	
	return 0;
}